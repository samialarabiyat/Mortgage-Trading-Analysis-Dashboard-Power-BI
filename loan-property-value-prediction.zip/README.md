
# 🏡 Loan Property Value Prediction using XGBoost

This project uses loan and borrower features to predict real estate property values using machine learning.  
The final model is based on **XGBoost Regressor** trained on cleaned loan data.

---

## 📁 Project Structure

- `data/`: Contains the final cleaned dataset
- `models/`: Saved trained model and scaler
- `notebook/`: Code notebook used for model training
- `README.md`: This file
- `requirements.txt`: Python libraries required

---

## 🔧 Features Used

- `sum_of_income_thousands`
- `monthly_income`
- `sum_of_median_fico_score`
- `sum_of_recurring_monthly_debt`
- `loan_type`
- `loan_purpose`
- `state_code`

Target variable: `sum_of_property_value`

---

## 🚀 Try it on Google Colab

Upload:
- `final_property_value_dataset.csv`
- Copy code from `property_value_model_training.ipynb`

---

## 📦 Installation

```bash
pip install -r requirements.txt
```

---

## 📈 Model Performance

- Model: XGBoost Regressor
- RMSE ≈ 307,568

---

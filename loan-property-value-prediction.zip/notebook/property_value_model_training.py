
# Property Value Prediction - XGBoost

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_squared_error
from xgboost import XGBRegressor
import joblib

# Load dataset
df = pd.read_csv("../data/final_property_value_dataset.csv")

# Prepare features
features = [
    "sum_of_income_thousands",
    "monthly_income",
    "sum_of_median_fico_score",
    "sum_of_recurring_monthly_debt",
    "loan_type",
    "loan_purpose",
    "state_code"
]

# Encode categorical columns
for col in df.select_dtypes(include='object').columns:
    df[col] = LabelEncoder().fit_transform(df[col])

X = df[features]
y = df["sum_of_property_value"]

# Scale
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Train model
model = XGBRegressor(n_estimators=100, learning_rate=0.1, random_state=42, n_jobs=2)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
rmse = mean_squared_error(y_test, y_pred, squared=False)
print("RMSE:", rmse)

# Save
joblib.dump(model, "../models/xgb_property_value_model.pkl")
joblib.dump(scaler, "../models/xgb_scaler.pkl")
